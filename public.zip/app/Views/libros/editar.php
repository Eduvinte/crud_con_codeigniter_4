<?=$header?>

     
<div class="container">
<div class="row">
    <div class="col-md-12">
        <form  method="post" action="<?=site_url('/actualizar')?>" enctype="multipart/form-data">

        <div class="form-group">

        <label for="">Nombre</label>
        <input type="text" name="nombre" value="<?=$libro['nombre']?>" id="nombre" class="form-control" placeholder="Nombre" aria-describedby="helpId">
        <small id="nombre"  class="text-muted">Ponga un nombre</small>

      
        <input type="hidden" class="form-control" value="<?=$libro['id']?>" name="id" id="inputName" placeholder="">


        <div class="form-group">
          <label for="imagen">Imagen</label><br>
          <img class="img-thumbnail" 
                                src="<?=base_url()?>/uploads/<?=$libro['imagen'];?>"  
                                width='250' srcset="">
          <input type="file" class="form-control-file" name="imagen" id="" placeholder="Ponga una imagen" aria-describedby="fileHelpId">
          <small id="imagen" class="form-text text-muted">Ponga alguna imagen</small>
        </div>

        <button class="btn btn-success" type="submit">
            Guardar
        </button>


        </div>
        </form>
    </div>
  
</div>
</div>


<?=$footer?>