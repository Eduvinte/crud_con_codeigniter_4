<?=$header?>

    <div class="container">

    <a class="btn btn-info mt-5 mb-5" type="button" href="<?=base_url('crear')?>">Crear um libro nuevo</a>
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Imagen</th>
                    <th>Nombre</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>

            <?php foreach($libros as $libro): ?>

                <tr>
              
                    <td><?=$libro['id'] ?></td>
                    <td>
                        


                        <img class="img-thumbnail" 
                                src="<?=base_url()?>/uploads/<?=$libro['imagen'];?>"  
                                width='250' srcset="">
                    </td>
                    <td><?=$libro['nombre'] ?></td>
                    <td>
                        <a href="<?=base_url('editar/'.$libro['id']);?>" class="btn btn-primary" type="button">Editar</a>
                        <a href="<?=base_url('borrar/'.$libro['id']);?>" class="btn btn-danger" type="button">Borrar</a>
                    </td>
                </tr>
            <?php endforeach; ?>

            </tbody>
        
           
        </table>
    </div>
<?=$footer?>